#include<stdio.h>
int a[10]={1,5,4,8,9,2,0,6,11,7}; 
int f = 0; 
void checkelement(int n){ 	
	for(int i=0;i<10;i++){ 		
		if (n == a[i]){ 			
			f=1; 		
			break; 		
		} 	
	} 	
		if(f == 0)	
		printf("No\n");  	
		else
 		printf("Yes\n");  
}
void printarray(){ 
	printf("array elemets are: "); 
	for (int i=0;i<10;i++){ 
		printf("%d ",a[i]); 
	} 	
	printf("\n");
} 
int main(){ 
 	int n;
 	printf("which number you want to check:"); 
	scanf("%d",&n); 
	checkelement(n);
 	printarray();
 	return 0;
}